###Code Version: 2.5
import socket
from newMove import Move
from threading import Thread

class socketServer():

    def __init__(self):
        self.moves = Move()
        self.moves.stop()
        self.flag = True
        self.tmpDirectionalValue = 0
        self.tmpVelocityValue = 0
        self.s = socket.socket()
        self.host = "0.0.0.0"
        self.port = 2608
        self.sc = 0
        self.addr = 0

    def run(self):
        try:
            self.s.bind((self.host, self.port))
            self.s.listen(1)
            print "Server up"

        except:
            print "Server Error"

        while True:

            self.sc, self.addr = self.s.accept()

            print "Received Connection from: " + str(self.addr[0]) + ":" + str(self.addr[1])
            self.sc.send("Password: \n")
            passwd = self.sc.recv(1024)
            if(passwd == "bop"):

                self.sc.send("on")

                while flag:
                    data = self.sc.recv(1024)
                    rcvData = data.split(":")
                    axi = int(rcvData[0])
                    value = int(rcvData[1])
                    directAxi = rcvData[2]
                    directValue = rcvData[3]

                    if(data == "exit"):
                        print data
                        print "Closing..."
                        flag = False
                        self.moves.exit()
                        self.sc.close()

                    elif (data == "help"):
                        print data
                        helps = "Instructions:\n Use the left axis for forward and backward movements, and the right axis for laterals movements."
                        self.sc.send(helps)

                    else:
                        #print data
                        print "Received: ", rcvData[0], ":", rcvData[1]


                        if(axi == 1):
                            Thread(target=self.moveUpDown,args=(value,))
                            #self.moveUpDown(value)

                        elif(directAxi== 2):
                            Thread(target=self.moveRightLeft, args=(directValue,))
                            #self.moveRightLeft(directValue)

                        else:
                            self.moves.stop()
            else:
                f = open("./logs/loginError.txt", "a")
                f.write(self.addr[0] + ":" + passwd + "\n")
                f.close()
                #moves.exit()
                self.sc.send("off")
                self.sc.close()

    def moveUpDown(self):
        if(self.value > 0):
            print self.value
            self.moves.stop()
            if(self.value != self.tmpVelocityValue):
                self.moves.forward(self.value)
                self.tmpVelocityValue = self.value
        elif(self.value < 0):
            print self.value
            value = (self.value * -1);
            self.moves.stop()
            if(value != self.tmpVelocityValue):
                self.moves.backward(value)
                self.tmpVelocityValue = value
        else:
            print self.value
            self.moves.stop()

    def moveRightLeft(self):
        if(self.value > 0):
            print self.value
            self.moves.directionalStop()
            if(self.value != self.tmpDirectionalValue):
                self.moves.right(self.value)
                self.tmpDirectionalValue = self.value
        elif(self.value < 0):
            print self.value
            value = (self.value * -1);
            self.moves.directionablStop()
            if(value != self.tmpDirectionalValue):
                self.moves.left(value)
                self.tmpDirectionalValue = value
        else:
            print self.value
            self.moves.stop()

Server = socketServer()
Server.run()